from django.contrib import admin

# Core app admin registrations will go here
